import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Trio — The Family Restaurant | Port Blair" },
      {
        name: "description",
        content:
          "Trio - The Family Restaurant in Port Blair, Andaman. Authentic North Indian and Chinese cuisine on ATR Road.",
      },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <main className="min-h-screen bg-background">
      <iframe
        src="/trio-restaurant.html"
        title="Trio — The Family Restaurant"
        className="h-screen w-full border-0"
      />
    </main>
  );
}
